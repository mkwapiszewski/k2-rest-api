﻿using Test.Domain.Models.Order;

namespace Test.Services
{
    public class OrdersService : IOrdersService
    {
        public CreateOrderResponse PostOrder(CreateOrderRequest product)
        {
            return null;
        }
    }
}
