﻿namespace Test.Domain.Models.Order
{
    public class CreateOrderResponse
    {
        public int Id { get; set; }
    }
}
